package com.tejait.batch11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Batch11Application {

	public static void main(String[] args) {
		SpringApplication.run(Batch11Application.class, args);
	}

}
